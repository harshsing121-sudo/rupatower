/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Phone, MessageSquare, MapPin, Building2, CheckCircle2, Menu, X, Maximize2, Train, Plane } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const PROPERTY_IMAGES = [
  {
    url: "https://lh3.googleusercontent.com/p/AF1QipNELnZPp6FjisnJpD9n9rAcfL3LJMc71cKMAvZX=s1360-w1360-h1020-rw",
    alt: "Modern Commercial Building Exterior"
  },
  {
    url: "https://lh3.googleusercontent.com/p/AF1QipNlxNxX8EZPVebznOpFJkJZh19shOQ95xuHf3CB=s1360-w1360-h1020-rw",
    alt: "Professional Office Interior"
  },
  {
    url: "https://lh3.googleusercontent.com/p/AF1QipPmiT5TYgnNL4Wavt8D66MNhjYhGR3psnTcZmnn=s1360-w1360-h1020-rw",
    alt: "Spacious Commercial Floor"
  },
  {
    url: "https://lh3.googleusercontent.com/p/AF1QipNYqOqiS9E-HYhtWEJu3RVKisqWLU1UcGqehaxn=s1360-w1360-h1020-rw",
    alt: "Corporate Reception Area"
  }
];

const CLIENTS = [
  "Mufti",
  "My Branch",
  "VLCC",
  "Aviyukt Infra Developers",
  "Grooming Galaxy",
  "The Toy Land",
  "The Gadgets Land"
];

export default function App() {
  const [currentImage, setCurrentImage] = useState(0);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isFloorPlanOpen, setIsFloorPlanOpen] = useState(false);

  // Auto-rotating carousel logic
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentImage((prev) => (prev + 1) % PROPERTY_IMAGES.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-white font-sans text-stone-900 selection:bg-stone-200">
      {/* Navigation */}
      <nav className="fixed top-0 z-50 w-full border-b border-stone-100 bg-white/80 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-3">
          <div 
            className="flex cursor-pointer items-center gap-2"
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          >
            <Building2 className="h-8 w-8 text-stone-900" />
            <span className="text-xl font-bold tracking-tight uppercase">Rupa Tower</span>
          </div>

          {/* Desktop Nav */}
          <div className="hidden items-center gap-8 md:flex">
            <button onClick={() => scrollToSection('about')} className="text-sm font-medium text-stone-600 hover:text-stone-900 transition-colors">About</button>
            <button onClick={() => scrollToSection('clients')} className="text-sm font-medium text-stone-600 hover:text-stone-900 transition-colors">Tenants</button>
            <button onClick={() => scrollToSection('contact')} className="rounded-full bg-stone-900 px-6 py-2 text-sm font-medium text-white hover:bg-stone-800 transition-all">
              Contact Now
            </button>
          </div>

          {/* Mobile Menu Toggle */}
          <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X /> : <Menu />}
          </button>
        </div>

        {/* Building Specs Ticker */}
        <div className="bg-stone-900 py-1.5 text-white overflow-hidden border-t border-white/5">
          <motion.div 
            className="flex whitespace-nowrap items-center"
            animate={{ x: ["0%", "-50%"] }}
            transition={{ 
              duration: 30, 
              ease: "linear", 
              repeat: Infinity 
            }}
          >
            {[1, 2].map((group) => (
              <div key={group} className="flex items-center">
                <motion.div 
                  animate={{ opacity: [0.7, 1, 0.7] }}
                  transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                  className="flex items-center"
                >
                  <span className="mx-8 text-[10px] font-bold uppercase tracking-[0.2em] text-stone-400 flex items-center gap-2">
                    <CheckCircle2 className="h-3 w-3 text-green-500" /> Approved Map from Local Body
                  </span>
                  <span className="mx-8 text-[10px] font-bold uppercase tracking-[0.2em] text-stone-400 flex items-center gap-2">
                    <CheckCircle2 className="h-3 w-3 text-green-500" /> Fire NOC
                  </span>
                  <span className="mx-8 text-[10px] font-bold uppercase tracking-[0.2em] text-stone-400 flex items-center gap-2">
                    <CheckCircle2 className="h-3 w-3 text-green-500" /> Lift Safety Certificate and AMC
                  </span>
                  <span className="mx-8 text-[10px] font-bold uppercase tracking-[0.2em] text-stone-400 flex items-center gap-2">
                    <CheckCircle2 className="h-3 w-3 text-green-500" /> 2 Passenger Lifts
                  </span>
                  <span className="mx-8 text-[10px] font-bold uppercase tracking-[0.2em] text-stone-400 flex items-center gap-2">
                    <CheckCircle2 className="h-3 w-3 text-green-500" /> 2 Fire Safety Stairs
                  </span>
                  <span className="mx-8 text-[10px] font-bold uppercase tracking-[0.2em] text-stone-400 flex items-center gap-2">
                    <CheckCircle2 className="h-3 w-3 text-green-500" /> 24 x 7 Security
                  </span>
                  <span className="mx-8 text-[10px] font-bold uppercase tracking-[0.2em] text-stone-400 flex items-center gap-2">
                    <CheckCircle2 className="h-3 w-3 text-green-500" /> CCTV for common area
                  </span>
                </motion.div>
              </div>
            ))}
          </motion.div>
        </div>

        {/* Mobile Nav Overlay */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="absolute left-0 top-full w-full border-b border-stone-100 bg-white p-6 md:hidden"
            >
              <div className="flex flex-col gap-4">
                <button onClick={() => scrollToSection('about')} className="text-left text-lg font-medium">About</button>
                <button onClick={() => scrollToSection('clients')} className="text-left text-lg font-medium">Tenants</button>
                <button onClick={() => scrollToSection('contact')} className="rounded-full bg-stone-900 px-6 py-3 text-center text-lg font-medium text-white">
                  Contact Now
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-24 pb-4 md:pt-32 md:pb-8 overflow-hidden">
        {/* Artistic Background Elements */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full -z-10 opacity-30">
          <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full bg-stone-200 blur-[120px]" />
          <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] rounded-full bg-stone-100 blur-[120px]" />
        </div>
        
        <div className="mx-auto max-w-7xl px-6">
          <div className="grid gap-8 lg:grid-cols-2 lg:items-center">
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
            >
              <div className="mb-6 inline-flex items-center gap-3 rounded-full border border-stone-200 bg-white/50 px-4 py-2 text-xs font-bold tracking-widest uppercase text-stone-500 backdrop-blur-sm">
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-stone-400 opacity-75"></span>
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-stone-600"></span>
                </span>
                Now Leasing: 3rd Floor Available
              </div>
              <h1 className="mb-6 text-4xl font-light leading-[1.1] tracking-tight text-stone-900 md:text-7xl">
                <motion.span 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 0.2 }}
                  className="block font-serif italic text-stone-400"
                >
                  Premium
                </motion.span>
                <motion.span 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 0.4 }}
                  className="block font-sans font-black uppercase tracking-tighter text-stone-900"
                >
                  Office Space
                </motion.span>
                <motion.span 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 0.6 }}
                  className="block text-2xl md:text-3xl font-serif text-stone-500 mt-2"
                >
                  in the Heart of Patna.
                </motion.span>
              </h1>
              <p className="mb-6 max-w-lg text-lg leading-relaxed text-stone-600">
                Rupa Tower offers state-of-the-art commercial spaces designed for modern businesses. Located at RPS More, Bailey Road, we provide the perfect environment for your corporate growth.
              </p>
              <div className="flex flex-wrap gap-4">
                <button 
                  onClick={() => scrollToSection('contact')}
                  className="flex items-center gap-2 rounded-full bg-stone-900 px-8 py-4 font-semibold text-white hover:bg-stone-800 transition-all"
                >
                  <Phone className="h-5 w-5" />
                  Enquire Now
                </button>
                <a 
                  href="https://wa.me/919771046294"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 rounded-full border border-stone-200 bg-white px-8 py-4 font-semibold text-stone-900 hover:bg-stone-50 transition-all"
                >
                  <MessageSquare className="h-5 w-5 text-green-600" />
                  WhatsApp
                </a>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ 
                opacity: 1, 
                scale: 1,
                y: [0, -10, 0]
              }}
              transition={{ 
                opacity: { duration: 0.8, delay: 0.2 },
                scale: { duration: 0.8, delay: 0.2 },
                y: { 
                  duration: 6, 
                  repeat: Infinity, 
                  ease: "easeInOut" 
                }
              }}
              className="relative aspect-[4/3] overflow-hidden rounded-3xl bg-stone-100 shadow-2xl"
            >
              <AnimatePresence mode="wait">
                <motion.img
                  key={currentImage}
                  src={PROPERTY_IMAGES[currentImage].url}
                  alt={PROPERTY_IMAGES[currentImage].alt}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.5 }}
                  className="h-full w-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </AnimatePresence>
              <div className="absolute bottom-6 left-1/2 flex -translate-x-1/2 gap-2">
                {PROPERTY_IMAGES.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setCurrentImage(i)}
                    className={`h-1.5 rounded-full transition-all ${
                      currentImage === i ? "w-8 bg-white" : "w-2 bg-white/50"
                    }`}
                  />
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Property Details */}
      <section id="about" className="bg-stone-50 pt-8 pb-16">
        <div className="mx-auto max-w-7xl px-6">
          <div className="mb-12 text-center">
            <h2 className="mb-4 text-3xl font-bold tracking-tight md:text-4xl">Building Specifications</h2>
            <div className="mx-auto h-1 w-20 bg-stone-900"></div>
          </div>
          
          <div className="grid gap-8 md:grid-cols-3">
            <div className="rounded-2xl bg-white p-8 shadow-sm transition-transform hover:-translate-y-1">
              <Building2 className="mb-6 h-10 w-10 text-stone-900" />
              <h3 className="mb-3 text-xl font-bold">Structure</h3>
              <p className="text-stone-600">B+G+5 Commercial Building with modern architectural design and robust infrastructure.</p>
            </div>
            
            <div className="rounded-2xl bg-white p-8 shadow-sm transition-transform hover:-translate-y-1">
              <MapPin className="mb-6 h-10 w-10 text-stone-900" />
              <h3 className="mb-3 text-xl font-bold">Location</h3>
              <p className="text-stone-600">Prime location at RPS More, Bailey Road, Patna. Excellent connectivity and high visibility.</p>
            </div>
            
            <div className="rounded-2xl bg-white p-8 shadow-sm transition-transform hover:-translate-y-1 flex flex-col">
              <CheckCircle2 className="mb-6 h-10 w-10 text-stone-900" />
              <h3 className="mb-3 text-xl font-bold">Available Space</h3>
              <p className="mb-6 text-stone-600">3,500 sq. ft. on the 3rd Floor (Front Side). Ideal for corporate offices, banks, or retail.</p>
              <button 
                onClick={() => setIsFloorPlanOpen(true)}
                className="mt-auto flex items-center justify-center gap-2 rounded-xl border border-stone-200 py-3 text-sm font-bold text-stone-900 transition-all hover:border-stone-900 hover:bg-stone-50"
              >
                <Maximize2 className="h-4 w-4" />
                View Floor Plan
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Salient Features / Connectivity */}
      <section className="bg-white py-16 border-t border-stone-100">
        <div className="mx-auto max-w-7xl px-6">
          <div className="mb-12 text-center">
            <h2 className="mb-4 text-3xl font-bold tracking-tight md:text-4xl">Salient Features</h2>
            <p className="text-stone-500">Strategic connectivity to major transport hubs.</p>
          </div>
          
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            <div className="flex items-center gap-4 rounded-2xl border border-stone-100 p-6 transition-all hover:border-stone-900 hover:shadow-md group">
              <div className="rounded-full bg-stone-100 p-3 group-hover:bg-stone-900 transition-colors">
                <Train className="h-6 w-6 text-stone-900 group-hover:text-white" />
              </div>
              <div>
                <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-stone-400">Danapur Station</p>
                <p className="text-lg font-bold text-stone-900">6 Km</p>
              </div>
            </div>

            <div className="flex items-center gap-4 rounded-2xl border border-stone-100 p-6 transition-all hover:border-stone-900 hover:shadow-md group">
              <div className="rounded-full bg-stone-100 p-3 group-hover:bg-stone-900 transition-colors">
                <Train className="h-6 w-6 text-stone-900 group-hover:text-white" />
              </div>
              <div>
                <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-stone-400">Metro Station</p>
                <p className="text-lg font-bold text-stone-900">0.5 Km</p>
              </div>
            </div>

            <div className="flex items-center gap-4 rounded-2xl border border-stone-100 p-6 transition-all hover:border-stone-900 hover:shadow-md group">
              <div className="rounded-full bg-stone-100 p-3 group-hover:bg-stone-900 transition-colors">
                <Plane className="h-6 w-6 text-stone-900 group-hover:text-white" />
              </div>
              <div>
                <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-stone-400">JP Narayan Airport</p>
                <p className="text-lg font-bold text-stone-900">5 Km</p>
              </div>
            </div>

            <div className="flex items-center gap-4 rounded-2xl border border-stone-100 p-6 transition-all hover:border-stone-900 hover:shadow-md group">
              <div className="rounded-full bg-stone-100 p-3 group-hover:bg-stone-900 transition-colors">
                <Train className="h-6 w-6 text-stone-900 group-hover:text-white" />
              </div>
              <div>
                <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-stone-400">Patna Jn Station</p>
                <p className="text-lg font-bold text-stone-900">10 Km</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Existing Clients */}
      <section id="clients" className="bg-stone-900 py-16 text-white overflow-hidden">
        <div className="mb-12 text-center px-6">
          <h2 className="mb-4 text-3xl font-bold tracking-tight md:text-4xl">Our Trusted Tenants</h2>
          <p className="text-stone-400">Join a community of prestigious brands already operating from Rupa Tower.</p>
        </div>
        
        <div className="relative flex overflow-hidden before:absolute before:left-0 before:top-0 before:z-10 before:h-full before:w-20 before:bg-gradient-to-r before:from-stone-900 before:to-transparent after:absolute after:right-0 after:top-0 after:z-10 after:h-full after:w-20 after:bg-gradient-to-l after:from-stone-900 after:to-transparent">
          <motion.div 
            className="flex whitespace-nowrap"
            animate={{ x: ["0%", "-50%"] }}
            transition={{ 
              duration: 25, 
              ease: "linear", 
              repeat: Infinity 
            }}
          >
            {/* Double the list for seamless loop */}
            {[...CLIENTS, ...CLIENTS].map((client, i) => (
              <div key={i} className="mx-4 flex items-center justify-center rounded-xl border border-white/10 bg-white/5 px-12 py-6 text-center transition-colors hover:bg-white/10">
                <span className="text-sm font-bold uppercase tracking-widest opacity-70">{client}</span>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16">
        <div className="mx-auto max-w-3xl px-6 text-center">
          <h2 className="mb-6 text-4xl font-bold tracking-tight">Ready to elevate your business?</h2>
          <p className="mb-12 text-lg text-stone-600">
            Schedule a site visit or get a customized quote for the available 3,500 sq. ft. space on the 3rd floor.
          </p>
          
          <div className="grid gap-8 md:grid-cols-3">
            <div className="flex flex-col items-center gap-4">
              <div className="rounded-full bg-stone-100 p-4">
                <MapPin className="h-6 w-6 text-stone-900" />
              </div>
              <div className="w-full">
                <h4 className="font-bold mb-4">Location</h4>
                <a 
                  href="https://maps.app.goo.gl/XP6ruK5x1GijK9pE6" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="group flex items-center justify-center gap-2 rounded-xl border border-stone-900 bg-stone-900 px-4 py-3 text-sm font-semibold text-white transition-all hover:bg-stone-800 active:scale-95"
                >
                  <MapPin className="h-4 w-4 text-stone-400 group-hover:text-white" />
                  Open in Maps
                </a>
              </div>
            </div>
            
            <div className="flex flex-col items-center gap-4">
              <div className="rounded-full bg-stone-100 p-4">
                <Phone className="h-6 w-6 text-stone-900" />
              </div>
              <div className="w-full">
                <h4 className="font-bold mb-4">Call Us</h4>
                <div className="flex flex-col gap-2">
                  <a 
                    href="tel:+919771046294" 
                    className="group flex items-center justify-center gap-2 rounded-xl border border-stone-200 bg-white px-4 py-3 text-sm font-semibold text-stone-900 transition-all hover:border-stone-900 hover:bg-stone-50 active:scale-95"
                  >
                    <Phone className="h-4 w-4 text-stone-400 group-hover:text-stone-900" />
                    +91 97710 46294
                  </a>
                  <a 
                    href="tel:+919686809794" 
                    className="group flex items-center justify-center gap-2 rounded-xl border border-stone-200 bg-white px-4 py-3 text-sm font-semibold text-stone-900 transition-all hover:border-stone-900 hover:bg-stone-50 active:scale-95"
                  >
                    <Phone className="h-4 w-4 text-stone-400 group-hover:text-stone-900" />
                    +91 96868 09794
                  </a>
                </div>
              </div>
            </div>
            
            <div className="flex flex-col items-center gap-4">
              <div className="rounded-full bg-green-50 p-4">
                <MessageSquare className="h-6 w-6 text-green-600" />
              </div>
              <div className="w-full">
                <h4 className="font-bold mb-4">WhatsApp</h4>
                <a 
                  href="https://wa.me/919771046294" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="group flex items-center justify-center gap-2 rounded-xl border border-green-100 bg-white px-4 py-3 text-sm font-semibold text-stone-900 transition-all hover:border-green-500 hover:bg-green-50 active:scale-95"
                >
                  <MessageSquare className="h-4 w-4 text-green-400 group-hover:text-green-600" />
                  Chat on WhatsApp
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-stone-100 bg-white py-12">
        <div className="mx-auto max-w-7xl px-6">
          <div className="flex flex-col items-center justify-between gap-8 md:flex-row">
            <div className="flex items-center gap-2">
              <Building2 className="h-6 w-6 text-stone-900" />
              <span className="text-lg font-bold tracking-tight uppercase">Rupa Tower</span>
            </div>
            
            <div className="text-center text-sm text-stone-500 md:text-left">
              © {new Date().getFullYear()} Rupa Tower. All rights reserved.
            </div>
            
            <div className="flex gap-6">
              <a href="tel:+919771046294" className="text-stone-400 hover:text-stone-900 transition-colors">
                <Phone className="h-5 w-5" />
              </a>
              <a href="https://wa.me/919771046294" target="_blank" rel="noopener noreferrer" className="text-stone-400 hover:text-stone-900 transition-colors">
                <MessageSquare className="h-5 w-5" />
              </a>
            </div>
          </div>
        </div>
      </footer>

      {/* Floor Plan Modal */}
      <AnimatePresence>
        {isFloorPlanOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center bg-stone-900/95 p-4 backdrop-blur-sm md:p-12"
            onClick={() => setIsFloorPlanOpen(false)}
          >
              <motion.div 
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="relative max-h-full max-w-6xl overflow-hidden rounded-2xl bg-white shadow-2xl"
                onClick={(e) => e.stopPropagation()}
              >
              <button 
                onClick={() => setIsFloorPlanOpen(false)}
                className="absolute right-4 top-4 z-10 rounded-full bg-stone-900/10 p-2 text-stone-900 transition-colors hover:bg-stone-900/20"
              >
                <X className="h-6 w-6" />
              </button>
              <div className="p-4 md:p-8">
                <div className="mb-4 flex items-center justify-between">
                  <div>
                    <h3 className="text-xl font-bold text-stone-900">3rd Floor Plan</h3>
                    <p className="text-sm text-stone-500">3,500 sq. ft. • Front Side</p>
                  </div>
                  <div className="hidden md:block">
                    <span className="rounded-full bg-stone-100 px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-stone-500">
                      Rupa Tower
                    </span>
                  </div>
                </div>
                <div className="overflow-auto flex justify-center">
                  <img 
                    src="https://i.ibb.co/xtNpFvD3/floor-plan.png" 
                    alt="Detailed Floor Plan" 
                    className="h-[70vh] w-auto rounded-lg object-contain"
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      // Fallback if the direct link guess fails
                      (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1574362848149-11496d93a7c7?q=80&w=2069&auto=format&fit=crop";
                    }}
                  />
                </div>
                <div className="mt-6 flex justify-center">
                  <button 
                    onClick={() => setIsFloorPlanOpen(false)}
                    className="rounded-full bg-stone-900 px-8 py-3 text-sm font-bold text-white hover:bg-stone-800"
                  >
                    Close Preview
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating WhatsApp Button */}
      <motion.div 
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 1, type: "spring", stiffness: 260, damping: 20 }}
        className="fixed bottom-6 right-6 z-50 flex items-center gap-3"
      >
        <a 
          href="https://wa.me/919771046294"
          target="_blank"
          rel="noopener noreferrer"
          className="group relative flex h-14 w-14 items-center justify-center rounded-full bg-green-500 text-white shadow-2xl transition-all hover:bg-green-600 hover:scale-110 active:scale-95"
        >
          <MessageSquare className="h-6 w-6" />
          <span className="absolute right-full mr-3 whitespace-nowrap rounded-lg bg-stone-900 px-3 py-1.5 text-xs font-bold text-white opacity-0 transition-all group-hover:opacity-100 hidden md:block">
            Chat with us
          </span>
        </a>
      </motion.div>
    </div>
  );
}
