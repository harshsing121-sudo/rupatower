
import { GoogleGenAI } from "@google/genai";

async function findImages() {
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: "Find 4 high-quality direct image URLs for 'Rupa Tower' located at RPS More, Bailey Road, Patna. These should be real photos of the building (exterior and interior if possible). Provide the URLs in a JSON array of objects with 'url' and 'alt' properties.",
    config: {
      tools: [{ googleSearch: {} }],
      responseMimeType: "application/json"
    },
  });

  console.log(response.text);
}

findImages();
