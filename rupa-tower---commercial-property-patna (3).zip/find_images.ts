import { GoogleGenAI } from "@google/genai";

async function findImages() {
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: "Find 4 high-quality direct image URLs for Rupa Tower, RPS More, Bailey Road, Patna. These should be from public sources like real estate sites or Google Maps if possible. Return them as a JSON array of objects with 'url' and 'alt' properties.",
    config: {
      tools: [{ googleSearch: {} }],
      responseMimeType: "application/json",
    },
  });
  console.log(response.text);
}

findImages();
